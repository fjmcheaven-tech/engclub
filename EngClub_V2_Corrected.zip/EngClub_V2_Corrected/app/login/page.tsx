"use client";

import { FormEvent, useState } from "react";
import Link from "next/link";
import { getSupabaseClient, isSupabaseConfigured } from "@/lib/supabase";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    const supabase = getSupabaseClient();
    if (!supabase) {
      setMessage("Supabase is not configured yet. Add your environment variables in Vercel.");
      return;
    }

    const { error } = await supabase.auth.signInWithPassword({ email, password });
    setMessage(error ? error.message : "Login successful.");
  }

  return (
    <main className="centerPage">
      <section className="authCard">
        <p className="eyebrow">WELCOME BACK</p>
        <h1>Sign in to EngClub</h1>
        <p className="muted">Use your EngClub account to continue.</p>

        <form onSubmit={handleSubmit}>
          <label>Email</label>
          <input
            type="email"
            value={email}
            onChange={(event) => setEmail(event.target.value)}
            placeholder="you@example.com"
            required
          />

          <label>Password</label>
          <input
            type="password"
            value={password}
            onChange={(event) => setPassword(event.target.value)}
            placeholder="••••••••"
            required
          />

          <button className="button primary full" type="submit">Sign in</button>
        </form>

        {!isSupabaseConfigured && (
          <p className="notice">Demo mode: Supabase environment variables are not configured yet.</p>
        )}
        {message && <p className="notice">{message}</p>}

        <Link href="/">← Back to home</Link>
      </section>
    </main>
  );
}
