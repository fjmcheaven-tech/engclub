import Link from "next/link";

export default function AdminPage() {
  return (
    <main className="portal">
      <header className="portalHeader">
        <div>
          <p className="eyebrow">ADMIN AREA</p>
          <h1>Administrator Portal</h1>
        </div>
        <Link className="button secondary" href="/dashboard">Dashboard</Link>
      </header>

      <section className="grid">
        <article className="card"><h2>User Management</h2><p>Add, review, and manage portal users.</p></article>
        <article className="card"><h2>Announcements</h2><p>Create important updates for the EngClub community.</p></article>
        <article className="card"><h2>Reports</h2><p>Monitor activity and portal information.</p></article>
      </section>
    </main>
  );
}
