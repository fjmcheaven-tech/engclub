import Link from "next/link";

export default function StudentPage() {
  return (
    <main className="portal">
      <header className="portalHeader">
        <div>
          <p className="eyebrow">STUDENT AREA</p>
          <h1>Student Portal</h1>
        </div>
        <Link className="button secondary" href="/dashboard">Dashboard</Link>
      </header>

      <section className="grid">
        <article className="card"><h2>My Lessons</h2><p>Access your available lessons and materials.</p></article>
        <article className="card"><h2>My Progress</h2><p>Track your learning journey and achievements.</p></article>
        <article className="card"><h2>Announcements</h2><p>Stay updated with the latest EngClub news.</p></article>
      </section>
    </main>
  );
}
