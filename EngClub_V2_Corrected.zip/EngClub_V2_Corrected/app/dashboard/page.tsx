import Link from "next/link";

const links = [
  { title: "Admin Portal", href: "/admin", description: "Manage the system and users." },
  { title: "Teacher Portal", href: "/teacher", description: "Manage classes and students." },
  { title: "Student Portal", href: "/student", description: "View learning progress and lessons." },
];

export default function DashboardPage() {
  return (
    <main className="portal">
      <header className="portalHeader">
        <div>
          <p className="eyebrow">ENGCLUB</p>
          <h1>Dashboard</h1>
        </div>
        <Link className="button secondary" href="/">Home</Link>
      </header>

      <section className="stats">
        <div className="stat"><strong>3</strong><span>Portal areas</span></div>
        <div className="stat"><strong>1</strong><span>Unified platform</span></div>
        <div className="stat"><strong>∞</strong><span>Learning opportunities</span></div>
      </section>

      <section className="grid">
        {links.map((item) => (
          <article className="card" key={item.href}>
            <h2>{item.title}</h2>
            <p>{item.description}</p>
            <Link href={item.href}>Open →</Link>
          </article>
        ))}
      </section>
    </main>
  );
}
