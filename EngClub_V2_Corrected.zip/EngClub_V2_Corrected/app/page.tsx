import Link from "next/link";

export default function Home() {
  return (
    <main className="home">
      <section className="hero">
        <div>
          <p className="eyebrow">ENGCLUB REAL PORTAL</p>
          <h1>Learn. Teach. Manage. Connect.</h1>
          <p className="lead">
            EngClub brings students, teachers, and administrators together in one simple portal.
          </p>
          <div className="heroActions">
            <Link className="button primary" href="/login">Sign in</Link>
            <Link className="button secondary" href="/dashboard">Open dashboard</Link>
          </div>
        </div>
      </section>

      <section className="features">
        <article className="card">
          <span>🛡️</span>
          <h2>Admin</h2>
          <p>Manage users, announcements, lessons, and portal activity.</p>
          <Link href="/admin">Go to Admin →</Link>
        </article>
        <article className="card">
          <span>👩‍🏫</span>
          <h2>Teachers</h2>
          <p>Organize classes, review students, and manage teaching tasks.</p>
          <Link href="/teacher">Go to Teacher Portal →</Link>
        </article>
        <article className="card">
          <span>🎓</span>
          <h2>Students</h2>
          <p>View lessons, track learning, and join your learning journey.</p>
          <Link href="/student">Go to Student Portal →</Link>
        </article>
      </section>
    </main>
  );
}
