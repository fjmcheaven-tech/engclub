import Link from "next/link";

export default function TeacherPage() {
  return (
    <main className="portal">
      <header className="portalHeader">
        <div>
          <p className="eyebrow">TEACHER AREA</p>
          <h1>Teacher Portal</h1>
        </div>
        <Link className="button secondary" href="/dashboard">Dashboard</Link>
      </header>

      <section className="grid">
        <article className="card"><h2>My Classes</h2><p>View and organize your current classes.</p></article>
        <article className="card"><h2>Students</h2><p>Review student information and progress.</p></article>
        <article className="card"><h2>Lessons</h2><p>Prepare and manage learning materials.</p></article>
      </section>
    </main>
  );
}
