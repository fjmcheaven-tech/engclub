# EngClub V2 — Real Portal Foundation

This is a corrected Next.js App Router project structure for GitHub and Vercel.

## Important folder structure

```text
engclub/
├── app/
│   ├── admin/
│   │   └── page.tsx
│   ├── dashboard/
│   │   └── page.tsx
│   ├── login/
│   │   └── page.tsx
│   ├── student/
│   │   └── page.tsx
│   ├── teacher/
│   │   └── page.tsx
│   ├── layout.tsx
│   ├── page.tsx
│   └── styles.css
├── lib/
│   └── supabase.ts
├── supabase/
│   └── schema.sql
├── .env.local.example
├── .gitignore
├── next-env.d.ts
├── package.json
├── tsconfig.json
└── README.md
```

## Vercel environment variables

Add these two values in Vercel:

- `NEXT_PUBLIC_SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY`

Do not upload `.env.local` to GitHub.

## Local development

```bash
npm install
npm run dev
```

## Build

```bash
npm run build
```

The project is structured so that the `app` directory is directly under the project root. This fixes the Vercel error: "Couldn't find any `pages` or `app` directory."
